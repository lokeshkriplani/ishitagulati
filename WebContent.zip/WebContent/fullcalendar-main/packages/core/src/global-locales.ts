import { LocaleInput } from './datelib/locale.js'

export const globalLocales: LocaleInput[] = []
