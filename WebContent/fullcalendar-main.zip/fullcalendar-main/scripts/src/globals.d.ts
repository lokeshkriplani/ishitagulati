
declare module '@rollup/plugin-node-resolve';
declare module 'rollup-plugin-dts';
