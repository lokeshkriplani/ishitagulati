describe('getEventSourceById', () => {
  xit('correctly retrieves an event source provided via `events` at initialization', () => {
  })

  xit('correctly retrieves an event source provided via `eventSources` at initialization', () => {
  })

  xit('correctly retrieves an event source provided via `addEventSource` method', () => {
  })
})
