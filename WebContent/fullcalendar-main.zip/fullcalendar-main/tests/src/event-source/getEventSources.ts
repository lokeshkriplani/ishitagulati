describe('getEventSources', () => {
  xit('correctly retrieves event sources provided via `events` at initialization', () => {
  })

  xit('correctly retrieves event sources provided via `eventSources` at initialization', () => {
  })

  xit('correctly retrieves event sources provided via `addEventSource` method', () => {
  })
})
