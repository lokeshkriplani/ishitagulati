
// NOTE: there are many jquery-related libs that our karma config implicitly includes
// They were being difficult with CJS/ESM

import './lib/global.css'
import './lib/global.js'
